module.exports = function(name){
    return 'Yo yo '+name+' - Welcome to Encore! This is from greet.js';
};